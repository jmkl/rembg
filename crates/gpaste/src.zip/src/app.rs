use crate::protocol::Message;
use crossbeam_channel::{Receiver, Sender};
use eframe::egui;
use std::time::Duration;

pub struct ChatGptApp {
    prompt: String,
    response: String,
    status: String,
    pending: bool,
    tx: Sender<Message>,
    rx: Receiver<Message>,
    next_id: u64,
}

impl ChatGptApp {
    pub fn new(tx: Sender<Message>, rx: Receiver<Message>) -> Self {
        Self {
            prompt: String::new(),
            response: String::new(),
            status: "Waiting for Chrome extension…".into(),
            pending: false,
            tx,
            rx,
            next_id: 1,
        }
    }

    fn poll_messages(&mut self, ctx: &egui::Context) {
        while let Ok(message) = self.rx.try_recv() {
            match message {
                Message::Hello { .. } => self.status = "Chrome native host connected".into(),
                Message::AssistantResponse { text, .. } => {
                    self.response = text;
                    self.pending = false;
                    self.status = "Response received".into();
                }
                Message::BridgeStatus { connected, detail } => {
                    self.status = if connected { format!("Connected: {detail}") } else { format!("Disconnected: {detail}") };
                }
                Message::BridgeError { error, .. } => {
                    self.status = format!("Error: {error}");
                    self.pending = false;
                }
                Message::SendPrompt { .. } => {}
            }
        }
        if self.pending { ctx.request_repaint_after(Duration::from_millis(100)); }
    }
}

impl eframe::App for ChatGptApp {
    fn logic(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        self.poll_messages(ctx);
    }

    fn ui(&mut self, ui: &mut egui::Ui, _frame: &mut eframe::Frame) {
        ui.add_space(10.0);
        ui.heading("ChatGPT Bridge");
        ui.label(&self.status);
        ui.separator();
        ui.label("Prompt");
        ui.add(egui::TextEdit::multiline(&mut self.prompt)
            .desired_rows(5)
            .hint_text("Type a prompt to send to the active ChatGPT tab…")
            .desired_width(f32::INFINITY));

        ui.horizontal(|ui| {
            let enabled = !self.pending && !self.prompt.trim().is_empty();
            let label = if self.pending { "Waiting for response…" } else { "Send to ChatGPT" };
            if ui.add_enabled(enabled, egui::Button::new(label)).clicked() {
                let message = Message::SendPrompt {
                    request_id: format!("req-{}", self.next_id),
                    text: self.prompt.trim().to_owned(),
                };
                self.next_id += 1;
                match self.tx.send(message) {
                    Ok(()) => {
                        self.pending = true;
                        self.response.clear();
                        self.status = "Prompt sent; waiting for ChatGPT…".into();
                    }
                    Err(error) => self.status = format!("Bridge worker unavailable: {error}"),
                }
            }
            if ui.button("Clear").clicked() { self.prompt.clear(); self.response.clear(); }
        });

        ui.separator();
        ui.label("Final assistant response");
        ui.add(egui::TextEdit::multiline(&mut self.response)
            .desired_rows(14)
            .desired_width(f32::INFINITY)
            .interactive(false));
        if ui.button("Copy response").clicked() { ui.ctx().copy_text(self.response.clone()); }
    }
}
