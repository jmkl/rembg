use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum Message {
    Hello { token: String },
    SendPrompt { request_id: String, text: String },
    AssistantResponse { request_id: String, text: String },
    BridgeStatus { connected: bool, detail: String },
    BridgeError { request_id: Option<String>, error: String },
}
