use serde_json::Value;
use std::{io::{self, BufReader, Read, Write}, net::TcpStream, sync::mpsc, thread, time::Duration};

const ADDRESS: &str = "127.0.0.1:38471";
const MAX_NATIVE_MESSAGE: usize = 64 * 1024 * 1024;

enum Event { FromChrome(Value), FromGui(String) }

fn read_native<R: Read>(reader: &mut R) -> io::Result<Option<Value>> {
    let mut header = [0u8; 4];
    let mut got = 0;
    while got < 4 {
        match reader.read(&mut header[got..])? {
            0 if got == 0 => return Ok(None),
            0 => return Err(io::Error::new(io::ErrorKind::UnexpectedEof, "truncated native message header")),
            n => got += n,
        }
    }
    let len = u32::from_le_bytes(header) as usize;
    if len == 0 || len > MAX_NATIVE_MESSAGE {
        return Err(io::Error::new(io::ErrorKind::InvalidData, format!("invalid native message length: {len}")));
    }
    let mut payload = vec![0; len];
    reader.read_exact(&mut payload)?;
    serde_json::from_slice(&payload).map(Some).map_err(|e| io::Error::new(io::ErrorKind::InvalidData, e))
}

fn write_native<W: Write>(writer: &mut W, value: &Value) -> io::Result<()> {
    let payload = serde_json::to_vec(value).map_err(io::Error::other)?;
    if payload.len() > 1024 * 1024 {
        return Err(io::Error::new(io::ErrorKind::InvalidData, "native host message exceeds 1 MiB"));
    }
    writer.write_all(&(payload.len() as u32).to_le_bytes())?;
    writer.write_all(&payload)?;
    writer.flush()
}

pub fn run() -> io::Result<()> {
    // Chrome owns stdin/stdout in native-host mode. Logs must go to stderr only.
    let mut stream = loop {
        match TcpStream::connect(ADDRESS) {
            Ok(stream) => break stream,
            Err(_) => thread::sleep(Duration::from_millis(500)),
        }
    };
    stream.set_nodelay(true)?;
    let mut gui_reader = BufReader::new(stream.try_clone()?);
    let (tx, rx) = mpsc::channel::<Event>();

    let chrome_tx = tx.clone();
    thread::spawn(move || {
        let stdin = io::stdin();
        let mut input = stdin.lock();
        loop {
            match read_native(&mut input) {
                Ok(Some(value)) => if chrome_tx.send(Event::FromChrome(value)).is_err() { break; },
                Ok(None) => break,
                Err(error) => {
                    let _ = chrome_tx.send(Event::FromChrome(serde_json::json!({"type":"bridge_error","error":error.to_string()})));
                    break;
                }
            }
        }
    });

    let gui_tx = tx.clone();
    thread::spawn(move || {
        use std::io::BufRead;
        let mut line = String::new();
        loop {
            line.clear();
            match gui_reader.read_line(&mut line) {
                Ok(0) => break,
                Ok(_) => if gui_tx.send(Event::FromGui(line.trim().to_owned())).is_err() { break; },
                Err(_) => break,
            }
        }
    });

    let stdout = io::stdout();
    let mut output = stdout.lock();
    for event in rx {
        match event {
            Event::FromChrome(value) => {
                let mut bytes = serde_json::to_vec(&value).map_err(io::Error::other)?;
                bytes.push(b'\n');
                if let Err(error) = stream.write_all(&bytes) { eprintln!("GUI socket write failed: {error}"); break; }
            }
            Event::FromGui(line) => match serde_json::from_str::<Value>(&line) {
                Ok(value) => if let Err(error) = write_native(&mut output, &value) { eprintln!("Chrome output failed: {error}"); break; },
                Err(error) => eprintln!("Invalid GUI message: {error}"),
            }
        }
    }
    Ok(())
}
